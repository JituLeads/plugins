<?php
// Template untuk menampilkan kontak info
function get_contact_info_markup() {
    include JITULEADS_PLUGIN_DIR . 'templates/contact-info-markup.php';
}