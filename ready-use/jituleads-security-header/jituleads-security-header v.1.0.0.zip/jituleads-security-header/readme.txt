=== JituLeads Security Header ===
Contributors: jituleads
Tags: security, headers, wordpress
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds security headers to WordPress to improve security. Auto-updates supported.
